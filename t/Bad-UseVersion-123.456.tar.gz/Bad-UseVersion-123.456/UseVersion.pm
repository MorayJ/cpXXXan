package Bad::UseVersion;

use version; $VERSION = qv('0.0.3');
