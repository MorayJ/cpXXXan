use strict;
use warnings;

package Mock::Dist;

use base qw(Test::MockObject);
use Test::More ();

my $null = sub {};

my @NULL = qw(verbose alert connect disconnect mlroot);

my %ALWAYS = (
  version_from_yaml_ok => 1,
);

sub new {
  my $self = shift->SUPER::new(@_);

  $self->mock($_ => $null) for @NULL;

  $self->set_always($_ => $ALWAYS{$_}) for keys %ALWAYS;

  return $self;
}

sub next_call_ok {
  my ($self, $method, $args, $label) = @_;
  unless ($label) {
    $label = "$method: " . join ", ", @$args;
    $label =~ s/\n$//;
    $label =~ s/\n.+$/.../s;
  }
  Test::More::is_deeply(
    [ $self->next_call ],
    [ $method => [ $self, @$args ] ],
    $label,
  );
}

sub verbose_ok {
  my ($self, $level, @what) = @_;
  $self->next_call_ok(verbose => [ $level, @what ]);
}

1;
