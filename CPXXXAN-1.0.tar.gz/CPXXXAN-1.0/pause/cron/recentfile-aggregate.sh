#!/bin/sh

export PATH=/usr/local/perl/bin:$PATH
rrr-aggregate /home/ftp/pub/PAUSE/authors/RECENT-1h.yaml
rrr-aggregate /home/ftp/pub/PAUSE/modules/RECENT-1h.yaml
