#!/bin/zsh


# wget --directory-prefix=/home/ftp/pub/PAUSE/authors/id/M/MU/MUIR --cut-dirs=3 --no-host-directories --verbose --append-output=/var/log/wget --accept gz -r -N -l 3  ftp://ftp.idiom.com/users/muir/CPAN
