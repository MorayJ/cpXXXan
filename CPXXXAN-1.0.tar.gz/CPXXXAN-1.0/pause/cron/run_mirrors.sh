#!/bin/sh

perl /usr/bin/mirror -C/home/k/PAUSE/mirror/mirror.defaults /home/k/PAUSE/mirror/mymirror.config
